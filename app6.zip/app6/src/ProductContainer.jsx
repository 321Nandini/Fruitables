import Product from "./Product"

function ProductContainer(props) {
    let {fruits}=props;
    let {filterFruits}=props;
    function handleBtnClick(product){
      props.onClick(product);
      // console.log(value);
    }
    function handleOnIncDec(value,product){
        props.onIncDec(value,product);
    }
    return (
      <>
        <div className=" container-product row">
          {
            fruits.map((e,index)=>
           <Product product={e} Index={index} key={index} onIncDec={handleOnIncDec} onClick={handleBtnClick}/>
            )
          }
        </div>
      </>
    )
  }
  
  export default ProductContainer