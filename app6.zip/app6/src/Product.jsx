function Product(props) {
  let { product } = props;
  let { Index } = props;
  function handleBtnClick() {
    props.onClick(product);
    console.log(Index);
  }
  function handleIncDec(value) {
    props.onIncDec(value, product);
    console.log(value);
  }

  return (
    <>
      <div className="col-lg-3 col-md-4 col-sm-6 product-card my-3 rounded p-2">
        <img
          src={"./public/images/" + product.image}
          alt={"img"}
          className="img-fluid cardImg"
        />
        {product.discount > 0 && (
          <div className="discount">{product.discount}% discount</div>
        )}
        <div className="m-2">{product.name}</div>
        <div className="m-2">Rs:{product.mrp}</div>
        <div>
          {product.qty <= 0 && (
            <div>
              {product.inStock ? (
                <button
                  className="btn btn-primary m-2"
                  onClick={handleBtnClick}
                >
                  Add to Cart
                </button>
              ) : (
                <button className="btn btn-danger m-2">Not in stock</button>
              )}
            </div>
          )}
          {product.qty > 0 && (
            <div>
              <div className="row">
                <div className="col-4">
                  <button
                    className="btn btn-primary"
                    onClick={() => handleIncDec("-")}
                  >
                    -
                  </button>
                </div>
                <div className="col-4">qty:{product.qty}</div>
                <div className="col-4">
                  <button
                    className="btn btn-primary"
                    onClick={() => handleIncDec("+")}
                  >
                    +
                  </button>
                </div>
              </div>
              <div>total:{product.qty * product.mrp}</div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default Product;
