import axios from "axios";

function AdminProduct(props) {
    let {product}=props;
    let {Index}=props;
    function handleEditButton(){
      console.log("admin product");
      
      props.onClickEditButtons(product);
    }
    function handleDeleteButton(){
      const userResponse = window.confirm(`Are you sure you want to delete the product ${product.name}?`);
      if (userResponse) {
            console.log("User clicked OK");
            deleteProduct(product);
      } else {
            console.log("User clicked Cancel");
      }
    }
    async function deleteProduct(p) {
           await axios.delete(`http://localhost:3000/fruits/${p.id}`);
           console.log("deleted");
           props.deleteProductSuccess(p);
    }
    return (
      <>
        <div className="col-lg-3 col-md-4 col-sm-6 product-card my-3 rounded p-2">
            <img src={"./public/images/"+product.image} alt={"img"} className="img-fluid" />
            <div className="m-2">{product.name}</div>
            <div className="m-2">Rs:{product.mrp}</div>
            <div className="row justify-content-center">
                <button className="col-4 w-25 bg-danger mx-4 my-3" onClick={handleEditButton}><i className="bi bi-pencil-square fs-4"></i></button>
                <button className="col-4 w-25 bg-danger mx-4 my-3" onClick={handleDeleteButton}><i className="bi bi-trash3-fill fs-4"></i></button>
            </div>
        </div>
      </>
    )
  }
  
  export default AdminProduct