import AddListProduct from "./AddListProduct";

function AddList(props) {
  let { fruits } = props;
  let { product } = props;
  let { cartList } = props;
  function handleEditAddBtn(p) {
    props.OnClickEditAddBtn(p);
  }
  function handleDeleteAddBtn() {
    props.OnClickDeleteAddBtn();
  }
  return (
    <>
      <div className="addListContainer row">
        {cartList.map((e, index) =>
          <AddListProduct
            product={e}
            key={index}
            OnClickEditAddBtn={handleEditAddBtn}
            OnClickDeleteAddBtn={handleDeleteAddBtn}
          />
        )}
      </div>
    </>
  );
}
export default AddList;
