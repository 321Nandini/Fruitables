function NavbarElements(props) {
  let { total } = props;
  let { userName } = props;
  function handleSearch(str) {
    props.onBtnClick(str);
    console.log(str);
  }
  function handleOnLogin() {
    props.onClickLoginBtn();
  }
  function handleOnSignUp() {
    props.onClickSignUpBtn();
  }
  function handleOnLogOut() {
    props.onClickLogOutBtn();
    
  }
  function handleCartBtn() {
    props.onClickCartBtn();
  }
  function handleOnGoBack() {
    props.onClickGoBackBtn();
  }
  function handleOnBuyProducts(){
    props.onClickBuyProducts();
  }
  return (
    <>
      <div className="container-nav bg-danger mb-5">
        <div className="div1 row">
          <div className="col-4">
            <img
              src="./public/images/poster.jpg"
              alt=""
              className="img-fluid img1"
            />
          </div>
          <div className="col-4 my-auto">
            <div className="row">
              {userName == "login" && (
                <div className="row">
                <div className="col-6">
                  <button
                    className="btn btn-light mx-2 col-6 w-75"
                    onClick={handleOnLogin}
                  >
                    Login
                  </button>
                </div>
                <div className="col-6">
                
                <button
                  className="btn btn-light mx-2 col-6 w-75"
                  onClick={handleOnSignUp}
                >
                  SignUp
                </button>
              </div></div>
              )}
              {userName == "logout" && (
                <div className="row">
                <div className="col-6">
                  <button
                    className="btn btn-light mx-2 col-6 w-75"
                    onClick={handleOnLogOut}
                  >
                    LogOut
                  </button>
                </div>
                <div className="col-6">
                
                <button
                  className="btn btn-light mx-2 col-6 w-75"
                  onClick={handleOnSignUp}
                >
                  SignUp
                </button>
              </div></div>
              )}
              {userName == "goBack" && (
                <div className="row">
                <div className="col-6">
                  <button
                    className="btn btn-light mx-2 col-6 w-75"
                    onClick={handleOnGoBack}
                  >
                    Go Back
                  </button>
                </div>
                {"  "}
                <div className="col-6">
               
                <button
                  className="btn btn-light mx-2 col-6 w-75"
                  onClick={handleOnBuyProducts}
                >
                  Buy products 
                </button>
              </div></div>
              )}
              
            </div>
          </div>
          <div className="col-4  my-auto">
            <button className="my-3" onClick={handleCartBtn}>
              <i className="bi bi-cart3 fs-3"></i>
            </button>
            <div className="text-white">Rs {total}</div>
          </div>
        </div>
        <div className="div2 row ">
          <input
            type="text"
            placeholder="Search..."
            className="my-4 w-50 mx-auto"
            onKeyUp={(e) => handleSearch(e.target.value)}
          />
        </div>
      </div>
    </>
  );
}

export default NavbarElements;
