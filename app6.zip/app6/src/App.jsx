import { useEffect, useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import NavbarElements from "./NavbarElements";
import ProductContainer from "./ProductContainer";
import axios from "axios";
import Loginbtn from "./Loginbtn";
import Signup from "./Signup";
import AdminContainer from "./AdminContainer";
import Edit from "./Edit";
import AddList from "./AddList";
import AddListProduct from "./AddListProduct";

function App() {
  // let fruits=[
  //   {
  //     id: "2",
  //     name: "Mango",
  //     image: "mango.jpg",
  //     unit: "doz",
  //     mrp: 500,
  //     discount: 8,
  //     inStock: true,
  //     qty: 0,
  //     type: "Organic"
  //   },
  //   {
  //     id: "3",
  //     name: "Banana",
  //     image: "banana.jpg",
  //     unit: "doz",
  //     mrp: 60,
  //     discount: 0,
  //     inStock: true,
  //     qty: 0,
  //     type: "Non-Organic"
  //   },
  //   {
  //     id: "4",
  //     name: "Apple",
  //     image: "apple.jpg",
  //     unit: "kg",
  //     mrp: 180,
  //     discount: 7,
  //     inStock: true,
  //     qty: 0,
  //     type: "Non-Organic"
  //   },
  //   {
  //     id: "5",
  //     name: "Anjeer",
  //     image: "anjeer.jpg",
  //     unit: "kg",
  //     mrp: 100,
  //     discount: 0,
  //     inStock: true,
  //     qty: 0,
  //     type: "Organic"
  //   },
  //   {
  //     id: "6",
  //     name: "Strawberry",
  //     image: "strawberry.jpg",
  //     unit: "kg",
  //     mrp: 200,
  //     discount: 20,
  //     inStock: true,
  //     qty: 0,
  //     type: "Non-Organic"
  //   },
  //   {
  //     id: "7",
  //     name: "Papaya",
  //     image: "papaya.jpg",
  //     unit: "kg",
  //     mrp: 50,
  //     discount: 15,
  //     inStock: true,
  //     qty: 0,
  //     type: "Organic"
  //   },
  //   {
  //     id: "8",
  //     name: "Cherry",
  //     image: "cherry.jpg",
  //     unit: "kg",
  //     mrp: 300,
  //     discount: 5,
  //     inStock: true,
  //     qty: 0,
  //     type: "Non-Organic"
  //   },
  //   {
  //     id: "9",
  //     name: "Chikoo",
  //     image: "chikoo.jpg",
  //     unit: "kg",
  //     mrp: 60,
  //     discount: 5,
  //     inStock: false,
  //     qty: 0,
  //     type: "Organic"
  //   },
  //   {
  //     id: "11",
  //     name: "Orange",
  //     image: "orange.jpg",
  //     unit: "kg",
  //     mrp: 200,
  //     discount: 10,
  //     inStock: true,
  //     qty: 0,
  //     type: "Non-Organic"
  //   },
  //   {
  //     id: "12",
  //     name: "Pear",
  //     image: "pear.jpg",
  //     unit: "kg",
  //     mrp: 200,
  //     discount: 7,
  //     inStock: true,
  //     qty: 0,
  //     type: "Non-Organic"
  //   },
  //   {
  //     id: "13",
  //     name: "Pineapple",
  //     image: "pineapple.jpg",
  //     unit: "piece",
  //     mrp: 100,
  //     discount: 50,
  //     inStock: true,
  //     qty: 0,
  //     type: "Non-Organic"
  //   },
  //   {
  //     id: "14",
  //     name: "Pomegranete",
  //     image: "pomegranete.jpg",
  //     unit: "kg",
  //     mrp: 200,
  //     discount: 5,
  //     inStock: true,
  //     qty: 0,
  //     type: "Non-Organic"
  //   },
  //   {
  //     id: "15",
  //     name: "Sitaphal",
  //     image: "sitaphal.jpg",
  //     unit: "kg",
  //     mrp: 100,
  //     discount: 10,
  //     inStock: true,
  //     qty: 0,
  //     type: "Organic"
  //   },
  //   {
  //     id: "16",
  //     name: "Watermelon",
  //     image: "watermelon.jpg",
  //     unit: "piece",
  //     mrp: 80,
  //     discount: 50,
  //     inStock: true,
  //     qty: 0,
  //     type: "Organic"
  //   },
  //   {
  //     id: "17",
  //     name: "Sweetlime",
  //     image: "sweetlime.jpg",
  //     unit: "kg",
  //     mrp: 200,
  //     discount: 5,
  //     inStock: true,
  //     qty: 0,
  //     type: "Non-Organic"
  //   },
  //   {
  //     id: "18",
  //     name: "Peach",
  //     image: "peach.jpg",
  //     unit: "kg",
  //     mrp: 200,
  //     discount: 10,
  //     inStock: false,
  //     qty: 0,
  //     type: "Non-Organic"
  //   },
  //   {
  //     id: "19",
  //     name: "Dragon",
  //     image: "dragon.jpg",
  //     unit: "piece",
  //     mrp: 60,
  //     discount: 0,
  //     inStock: true,
  //     qty: 0,
  //     type: "Non-Organic"
  //   }
  // ]
  useEffect(() => {
    getDataFromServer();
  }, []);
  async function getDataFromServer() {
    let response = await axios("http://localhost:3000/fruits");
    let pList = await response.data;
    setFruits(pList);
  }
  let [Fruits, setFruits] = useState([]);
  let [ttl, setTtl] = useState(0);
  let [fiteredProduct, setFilteredProducts] = useState([]);
  let [userview, setUserview] = useState("user");
  let [userName, setUserName] = useState("login");
  let [currentProduct, setCurrentProduct] = useState({});
  let [adminView, setAdminView] = useState("");
  let [cartList, setCartList] = useState([]);
  let [currentUser, setCurrentUser] = useState([]);

  let filteredFruits = [];
  function settleCartList(p) {
    setCartList((prevCartList) => {
      if (prevCartList.some((e) => e.id === p.id)) {
        console.log("same id");
        return prevCartList; // Do not add duplicate items
      } else {
        console.log("diff id");
        return [...prevCartList, p]; // Add new item
      }
    });
  }
  function handleBtn(str) {
    if (str == " ") {
      filteredFruits = pList;
    } else {
      filteredFruits = pList.filter((fruit) =>
        fruit.name.toLowerCase().startsWith(str.toLowerCase())
      );
      setFruits(filteredFruits);
    }
    setFruits(filteredFruits);
    setFilteredProducts(prlist);
  }
  function handleBtnClick(product) {
    let prlist = Fruits.map((e) => {
      if (e.id == product.id) {
        e.qty += 1;
        setCurrentProduct(e);
        settleCartList(e);
      }
      return e;
    });
    setFruits(prlist);
    setTtl(Number(ttl) + Number(product.qty) * Number(product.mrp));
    setFilteredProducts(prlist);
  }
  function handleOnIncDec(value, product) {
    console.log(value);
    let prlist = [];
    if (value == "+") {
      prlist = Fruits.map((e) => {
        if (e.id == product.id) {
          e.qty += 1;
          console.log(e.qty);
          setCurrentProduct(e);
          settleCartList(e);
        }
        return e;
      });
      setTtl(Number(ttl) + Number(product.mrp));
    } //if
    else if (value == "-") {
      // setTtl(ttl-(product.qty*product.mrp));
      prlist = Fruits.map((e) => {
        if (e.id == product.id) {
          e.qty -= 1;
          console.log(e.qty);
          setCurrentProduct(e);
          settleCartList(e);
        }
        return e;
      });
      setTtl(Number(ttl) - Number(product.mrp));
    }
    setFruits(prlist);
    setFilteredProducts(prlist);
  }
  function handleOnClickLoginBtn() {
    setUserview("login");
    setUserName("logout");
  }
  function handleOnClickSignUpBtn() {
    setUserview("signUp");
  }
  function handleOnClickLogOutBtn() {
    const userResponse = window.confirm(`Are you sure you want to LogOut?`);
    if (userResponse) {
      console.log("User clicked OK");
      window.location.reload();
    } else {
      console.log("User clicked Cancel");
    }
    setUserName("login");
    setUserview("user");
    setCurrentUser([]);
  }
  function handleOnLoginSuccess(userData) {
    if (userData.role == "user") {
      setUserview("user");
    } else {
      setUserview("admin");
    }
    setCurrentUser(userData);
  }
  function handleOnLoginBtnClick() {
    setUserview("login");
    setUserName("logout");
  }
  function handleCartBtn() {
    if (currentUser == null) {
      console.log("Login first!!!");
    }
    setUserview("addList");
    setUserName("goBack");
  }
  function handleEditButton(product) {
    setCurrentProduct(product);
    setAdminView("edit");
    setUserview("Edit");
  }
  function handleEditProductSuccess(product) {
    let prlist = Fruits.map((e) => {
      if (e.id == product.id) {
        return { ...product };
      }
      return e;
    });
    setFruits(prlist);
    setFilteredProducts(prlist);
    setUserview("admin");
  }
  function handleDeleteProductSuccess(product) {
    let prlist = Fruits.filter((e) => e.id != product.id);
    setFruits(prlist);
    setFilteredProducts(prlist);
    setUserview("admin");
  }
  function handleOnClickAddProductbtn() {
    setAdminView("add");
    setUserview("Edit");
    console.log("hiiii");
  }
  function handleAddProductSuccess(p) {
    let prlist = { ...Fruits, p };
    setFruits(prlist);
    setFilteredProducts(prlist);
    setUserview("admin");
  }
  function handleEditAddBtn(p) {
    console.log(p.qty);
    // let prlist = Fruits.map((e) => {
    //   if (e.id =p.id) {
    //     return { ...p};
    //   }
    //   return e;
    // });
    // setFruits(prlist);
    // setFilteredProducts(prlist);
  }
  function handleDeleteAddBtn() {
    console.log("u can Delete the product now.");
  }
  function handleOnClickGoBackBtn() {
    setUserview("user");
    setUserName("login");
  }
  function handleOnBuyProducts() {
    console.log("you are successful in buying products...");
    setUserview("buyProduct");
  }
  return (
    <>
      {" "}
      <div className="main-box">
        <NavbarElements
          fruits={Fruits}
          onBtnClick={handleBtn}
          total={ttl}
          onClickLoginBtn={handleOnClickLoginBtn}
          onClickSignUpBtn={handleOnClickSignUpBtn}
          onClickLogOutBtn={handleOnClickLogOutBtn}
          onClickCartBtn={handleCartBtn}
          onClickGoBackBtn={handleOnClickGoBackBtn}
          onClickBuyProducts={handleOnBuyProducts}
          userName={userName}
        />
      </div>
      <div className="container-product">
        {userview == "user" && (
          <ProductContainer
            fruits={Fruits}
            filterFruits={fiteredProduct}
            onClick={handleBtnClick}
            onIncDec={handleOnIncDec}
          />
        )}
        {userview == "login" && (
          <Loginbtn onLoginSuccess={handleOnLoginSuccess} />
        )}
        {userview == "signUp" && (
          <Signup onLoginButtonClick={handleOnLoginBtnClick} />
        )}

        {userview == "admin" && (
          <AdminContainer
            fruits={Fruits}
            onClickEditButton={handleEditButton}
            filterFruits={fiteredProduct}
            deleteProductSuccess={handleDeleteProductSuccess}
            onClickAddProductbtn={handleOnClickAddProductbtn}
          />
        )}
        {userview == "Edit" && (
          <Edit
            fruits={Fruits}
            adminView={adminView}
            filterFruits={fiteredProduct}
            product={currentProduct}
            editProductSuccess={handleEditProductSuccess}
            addProductSuccess={handleAddProductSuccess}
          />
        )}
        {userview == "addList" && (
          <AddList
            fruits={Fruits}
            product={currentProduct}
            cartList={cartList}
            OnClickEditAddBtn={handleEditAddBtn}
            OnClickDeleteAddBtn={handleDeleteAddBtn}
          />
        )}
        {userview == "buyProduct" && (
          <Cart product={currentProduct} user={currentUser} />
        )}
      </div>
    </>
  );
}

export default App;
