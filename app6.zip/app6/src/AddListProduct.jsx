import { useState } from "react";

function AddListProduct(props) {
  let { product } = props;
  let [p,setP]=useState(product);
  function handleEditAddBtn(e) {
    let p={...product};
      p[e.target.name]=e.target.value;
      setP(p);
    props.OnClickEditAddBtn(p);
  }
  function handleDeleteAddBtn() {
    props.OnClickDeleteAddBtn();
  }
  return (
    <>
      {p.qty!=0 &&<div className="justify-content-center row my-2">
        <div className="col-5 bg-danger mx-2 fs-4 text-white rounded text-center pt-2">
          {product.name}
        </div>
        {/* <button className="col-3 bg-danger mx-2 " onClick={handleEditAddBtn}>
          <i className="bi bi-pencil-square fs-4"></i>
           </button> */}
        <div
          className="col-5 bg-danger mx-2 text-white justify-content-center pt-2 rounded"
         
        >
          No. of items: <input type="number" className="w-25 " name="qty" value={p.qty} placeholder={product.qty} onChange={(e) => handleEditAddBtn(e)} /> {product.unit}
        </div>
        {" "}
        <button className="col-1 bg-danger mx-2" onClick={handleDeleteAddBtn}>
          <i className="bi bi-trash3-fill fs-4"></i>
        </button>
      </div>}
    </>
  );
}
export default AddListProduct;
