import AdminProduct from "./AdminProduct";


function AdminContainer(props) {
    let {fruits}=props;
    let {filterFruits}=props;
    function handleEditButtons(product){
        
        
        props.onClickEditButton(product);
        console.log("admin container");
    }
    function handleDeleteProductSuccess(p){
      props.deleteProductSuccess(p);
    }
    function handleOnClickAddProductbtn(){
           props.onClickAddProductbtn();
    }
    return (
      <> <div className="container-product">
         <div className="text-center"><button className="btn btn-danger mx-auto col-6 w-25 text-light" onClick={handleOnClickAddProductbtn}>Add Product</button></div>
        <div className="  row">
          {
            fruits.map((e,index)=>
           <AdminProduct product={e} Index={index} key={index} onClickEditButtons={handleEditButtons} deleteProductSuccess={handleDeleteProductSuccess}/>
            )
          }
        </div>
        </div>
      </>
    )
  }
  
  export default AdminContainer