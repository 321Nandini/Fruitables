import { useState, useEffect } from "react";

const Cart = (props) => {
    const [cart, setCart] = useState([]);
    let {user}=props;
    let {product}=props;
    const userId = localStorage.getItem("userId") ;
    // let userId=user.id;

    // Load cart for the specific user when the component mounts
    useEffect(() => {
        const savedCart = localStorage.getItem(`cart_${userId}`);
        if (savedCart) {
            setCart(JSON.parse(savedCart));
        }
    }, [userId]);

    // Save cart to local storage whenever it changes
    useEffect(() => {
        localStorage.setItem(`cart_${userId}`, JSON.stringify(cart));
    }, [cart, userId]);

    // Function to add an item
    const addToCart = (item) => {
        setCart([...cart, item]);
    };

    // Function to remove an item
    const removeFromCart = (index) => {
        const updatedCart = cart.filter((_, i) => i !== index);
        setCart(updatedCart);
    };

    // Function to clear the cart
    const clearCart = () => {
        setCart([]);
        localStorage.removeItem(`cart_${userId}`);
    };

    return (
        <div>
            <h2>Shopping Cart</h2>
            {cart.length === 0 ? <p>Cart is empty</p> : cart.map((item, index) => (
                <div key={index}>
                    <p>{item.name} - ${item.price}</p>
                    <button onClick={() => removeFromCart(index)}>Remove</button>
                </div>
            ))}
            <button onClick={() => addToCart({ name: "Laptop", price: 1000 })}>
                Add Laptop
            </button>
            <button onClick={clearCart}>Clear Cart</button>
        </div>
    );
};

export default Cart;
