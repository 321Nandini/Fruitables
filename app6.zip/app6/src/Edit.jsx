import axios from "axios";
import { useEffect, useState } from "react";
import { BeatLoader } from "react-spinners";

function Edit(props) {
  let [product,setproduct]=useState("");
  let [loader,setLoader]=useState(false);
  let {adminView}=props;
  let emptyProduct = {
    name: "",
    mrp: "",
    discount: "",
    unit:"",
    inStock:true,
    image:"noImage.png",
    qty:0
  };

  useEffect(()=>{
    if(adminView=="edit"){
      setproduct(props.product);
    }
    else if(adminView=="add"){
      setproduct(emptyProduct);
    }
  },[]);
  
  
  function handleChange(event){
      let p={...product};
      p[event.target.name]=event.target.value;
      setproduct(p);
  }
  function handleRadioChange(e){
    let p={...product};
    if(e.target.value=="on"){
      p.inStock=false;
    }
    else {
      p.inStock=true;
    }
    setproduct(p);
    console.log(p.inStock);
    
  }
  function handleEditFormSubmit(event) {
    event.preventDefault();
    let formData = new FormData(event.target);
    let EditedProduct = {};
    for (let data of formData) {
      EditedProduct[data[0]] = data[1];
    }
    EditedProduct.image=product.image;
    EditedProduct.id=product.id;
    EditedProduct.qty=product.qty;
    EditedProduct.inStock=product.inStock;
    EditedProduct.type=product.type;
    console.log(EditedProduct);
    if(adminView=="edit"){
      EditProduct(EditedProduct,product.id);
    }
    else if(adminView=="add"){
      AddProduct(EditedProduct);
    }
     
  }
  async function EditProduct(EditedProduct,productId) {
    setLoader(true);
    let response = await axios.put(`http://localhost:3000/fruits/${productId}`,EditedProduct);
    let data = await response.data;
    console.log(data);
    props.editProductSuccess(EditedProduct);
    setLoader(false);
    
  }
  async function AddProduct(EditedProduct)
  {
    setLoader(true);
    let response=await axios.post(`http://localhost:3000/fruits/`,EditedProduct);
    let data = await response.data;
    console.log(data);
    props.addProductSuccess(EditedProduct);
    setLoader(false);
  }
  if(loader){
    return(
      <>
         <BeatLoader size={24} color={"red"} />;
      </>
    )
  }
  return (
    <>
        <div className="row justify-content-center">
          <div className="text-center text-danger my-3">LOGIN</div>
          <div className="col-sm-12 col-md-6  border border-3 border-danger">
            <form
              className="loginForm"
              onSubmit={(event) => {
                handleEditFormSubmit(event);
              }}
            >
              <div className="row">
                <div className="col-sm-4 col-6 my-2 text-end">Name:</div>
                <div className="col-6 my-2">
                  <input type="text" name="name" id="" value={product.name} onChange={(e)=>handleChange(e)} />
                </div>
                <div className="col-sm-4 col-6 my-2 text-end">Price:</div>
                <div className="col-6 my-2">
                  <input type="number" name="mrp" id="" value={product.mrp} onChange={(e)=>handleChange(e)}  />
                </div>
                <div className="col-sm-4 col-6 my-2 text-end">Discount:</div>
                <div className="col-6 my-2">
                  <input type="number" name="discount" id="" value={product.discount} onChange={(e)=>handleChange(e)} />
                </div>
                <div className="col-sm-4 col-6 my-2 text-end">Unit:</div>
                <div className="col-6 my-2">
                  <input type="text" name="unit" id="" value={product.unit} onChange={(e)=>handleChange(e)} />
                </div>
                </div>
                <div className="row mt-2 mb-3">
                <input type="radio" className="col-6  w-25" name="inStock" id="" value={product.inStock} onChange={handleRadioChange}/>In stock
                <input type="radio" className="col-6  w-25" name="inStock" id=""  onChange={handleRadioChange}/>Not in stock
                </div>
                
                <div className="col-sm-4 col-6  my-2 text-end"></div>
                <div className="row my-3 justify-content-center">
                  <input className="btn btn-danger col-6 w-25 mx-2" type="submit" value="Ok" />{" "}
                  <input
                    className="btn btn-danger col-6 w-25 mx-2"
                    type="reset"
                    value="Clear"
                  />
                </div>
            
            </form>
          </div>
        </div>
      

      {/* row ends */}
    </>
    
  );
}

export default Edit;